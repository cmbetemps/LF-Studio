package regex;

import java.util.ArrayList;
import java.io.FileWriter;
import java.io.PrintWriter;

public class Main {
  public static void main(String[] args) throws Exception {
    ArrayList<String> out = new ArrayList<String>();

    String input = "(0|1*).(0|1)*";
    // String input = "((1|0).00)";

    out.addAll(Input.testCalc(input));
    System.out.println("Input = " + input);
    System.out.println("\u03A3 = " + out);

    // FUNÇAO QUE ESCREVE NO ARQUIVO TEXTO
    FileWriter arq = new FileWriter("linguagem.txt", true);
    PrintWriter gravarArq = new PrintWriter(arq);
    gravarArq.printf("\u03A3 = {");
    for (int i = 0; i < out.size(); i++) {
      gravarArq.printf(out.get(i) + ",\n");
    }
    arq.close();

  }

}
