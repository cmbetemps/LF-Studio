# expressao-regular-lf

    Para executar no terminal:
        $ javac main.java
        $ java main